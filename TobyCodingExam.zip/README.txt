The project contains two scripts, a test.js which is the solution, a helper.html which is a simple website to faciliate the test.

test.js:

class: RangeList

property: rangeList=>an array which stores all the ranges of the RangeList

functions:

add(range) => Adds a range to the list
@param {Array<number>} range - Array of two integers that specifybeginning and end of range.

remove(range) => Removes a range from the list
@param {Array<number>} range - Array of two integers that specifybeginning and end of range.

insert(index, element) => insert an element after the given index; 
@param Object element - the element needed to be inserted.
@param int index - the index where the element will be inserted after.

print() => provide the desired string output format



helper.html:

"add" and "remove" buttons with corresponding input bar as a test tool. Once input a valid valid and click the add or remove button, the result wil be showed in the Result part.