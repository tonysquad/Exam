class RangeList{

    constructor() {
        this.rangeList = [];
    }

    //insert an element into this.rangeList after the given index
    //this function cost O(n) times, we do not use slice() to trade time for space improvement
    insert(index, element){
        /**
         * * insert an element after the given index
         * * @param Object element - the element needed to be inserted.
         * * @param int index - the index where the element will be inserted after.
         * */

        //check if index is an integer
        if(!(typeof index === 'number' && index % 1 === 0)){
            return;
        }

        var pre, next = this.rangeList[index];
        this.rangeList[index] = element;

        //shift the elements after inserting the element
        var size = this.rangeList.length;
        for(var i = index + 1; i < size; i++){
            pre = this.rangeList[i];
            this.rangeList[i] = next;
            next = pre;
        }
        this.rangeList[size] = next;
    }

    //add and recombine an range to existing rangeList
    add(range){
        /**
         * * Adds a range to the list
         * * @param {Array<number>} range - Array of two integers that specifybeginning and end of range.
         * */
        if(range[0] < range[1]){

            //if our array is empty, just add the range to the array and return
            if(this.rangeList.length == 0){
                this.rangeList[0] = range;
                return;
            }

            var i = 0;
            for(; i < this.rangeList.length; i++){
                //if the input range has already exists in the rangeList, stop the function
                if(range[0] > this.rangeList[i][0] && range[1] < this.rangeList[i][1]){
                    return;
                }
                //case1: expanding an existing range to the left side; e.g, [10, 12] vs [2, 20]
                if(this.rangeList[i][0] >= range[0] && this.rangeList[i][1] < range[1]){
                    this.rangeList[i] = range;

                    return;
                }
                //case2: expanding an existing range to the left side; e.g, [2, 12] vs [10, 21]
                else if(this.rangeList[i][0] <= range[1] && this.rangeList[i][0] >= range[0]
                    && this.rangeList[i][1] >= range[1]){

                    this.rangeList[i] = [range[0], this.rangeList[i][1]];
                    return;
                }
                //case3: expanding an existing range to the right side; e.g, [12, 40] vs [10, 21]
                else if(this.rangeList[i][1] >= range[0] && this.rangeList[i][1] <= range[1] &&
                    this.rangeList[i][0] <= range[0]){

                    this.rangeList[i] = [this.rangeList[i][0], range[1]];
                    return;
                }
                //all the above cases are trying to avoid insertion, since inserting an element into an array will
                //lead to O(n) time consumption. but if we get here, insertion is unavoidable
                else if(this.rangeList[i+1]){
                    if(range[0] > this.rangeList[i][1] && range[1] < this.rangeList[i+1][0]){
                        this.insert(i, range);
                        return;
                    }
                }
            }

            //we have to take appending as a special case to deal with
            if(i == this.rangeList.length){
                this.rangeList[i] = range;
                return;
            }
        }
    }

    remove(range){
     /**
     * * Removes a range from the list
     * * @param {Array<number>} range - Array of two integers that specifybeginning and end of range.
     * */
        if(range[0] < range[1]){
            var newArray = [];
            for(var i = 0; i < this.rangeList.length; i++){

                //case1: shrink both sides; split into two ranges
                if(range[0] > this.rangeList[i][0] && range[1] < this.rangeList[i][1]){
                    newArray[newArray.length] = [this.rangeList[i][0], range[0]];
                    newArray[newArray.length] = [range[1], this.rangeList[i][1]];
                }
                //case2: range is larger than current rangeList[i], ignore this one
                else if(range[0] < this.rangeList[i][0] && range[1] > this.rangeList[i][1]){
                    continue;
                }
                //case3: shrink the left side
                else if(range[0] < this.rangeList[i][1] && range[0] > this.rangeList[i][0]){
                    newArray[newArray.length] = [this.rangeList[i][0], range[0]];
                }
                //case4: shrink the right side
                else if(range[1] > this.rangeList[i][0] && range[1] < this.rangeList[i][1]){
                    newArray[newArray.length] = [range[1], this.rangeList[i][1]];
                }
                //nothing should happen, just copy rangeList[i] to the new array
                else {
                    newArray[newArray.length] = this.rangeList[i];
                }
            }
            this.rangeList = newArray;
        }
    }

    print(){
        var str = " ";
        for(var i = 0; i < this.rangeList.length; i++){
            str += "[" + this.rangeList[i][0] + ", " + this.rangeList[i][1] + ") ";
        }
        console.log(str);
        return str;
    }
}
